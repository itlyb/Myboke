<!DOCTYPE HTML>
<html>
<head>
<title>IT_LYB 博客个人博客 — 一个站在PHP开发之路上的草根程序员个人博客网站</title>
<meta charset="utf-8">
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" />
<meta http-equiv="Cache-Control" content="no-siteapp" />
<meta name="keywords" content="个人博客,IT_LYB 博客个人博客,个人博客系统,IT_LYB 博客博客,IT_LYB 博客">
<meta name="description" content="IT_LYB 博客博客系统，一个站在PHP开发之路上的草根程序员个人博客网站。">
<LINK rel="Bookmark" href="favicon.ico" >
<LINK rel="Shortcut Icon" href="favicon.ico" />
<!--[if lt IE 9]>
<script type="text/javascript" src="/staticRes/js/html5shiv.js"></script>
<script type="text/javascript" src="/staticRes/js/respond.min.js"></script>
<![endif]-->
<link rel="stylesheet" type="text/css" href="plugin/h-ui/css/H-ui.min.css" />
<link rel="stylesheet" type="text/css" href="plugin/Hui-iconfont/1.0.8/iconfont.min.css" />
<link rel="stylesheet" type="text/css" href="css/common.css" />
<link rel="stylesheet" type="text/css" href="plugin/pifu/pifu.css" />
<!--[if lt IE 9]>
<link href="/staticRes/lib/h-ui/css/H-ui.ie.css" rel="stylesheet" type="text/css" />
<![endif]-->
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } function showSide(){$('.navbar-nav').toggle();}</script>
</head>
<body>

@include('layout.nav')

<!--导航条-->
<nav class="breadcrumb">
    <div class="container">
        <i class="Hui-iconfont">&#xe67f;</i><a href="/" class="c-primary">首页</a>
        <span class="c-gray en">&gt;</span> <a href="/article" class="c-primary">学无止尽</a>
        <!-- <span class="c-gray en">&gt;</span> <span class="c-gray"><i class="Hui-iconfont">&#xe64b;</i> nginx</span> -->
    </div>
</nav>

<section class="container">
  <!--left-->
  <div class="col-sm-9 col-md-9 mt-20">
  	
  		
  	<!--article list-->
			<ul class="index_arc">

				@foreach($articles as $k => $v)
				<li class="index_arc_item">
					<a href="/item?art={{$v['id']}}" class="pic">
						<img class="lazyload" data-original="uploads/{{$v['img']}}" alt="应该选" />
					</a>
					<h4 class="title"><a href="/item?art={{$v['id']}}">{{$v['title']}}</a></h4>
					<div class="date_hits">
						<span>IT_LYB</span>
						<span>{{$v['created_at']}}</span>
						<span><a href="/article-lists/10.html">{{$type[$k]['name']}}</a></span>
						<p class="hits"><i class="Hui-iconfont" title="点击量">&#xe6c1;</i> 276° </p>
						<p class="commonts"><i class="Hui-iconfont" title="点击量">&#xe622;</i> <span class="cy_cmt_count">20</span></p>
					</div>
					<div class="desc">
						{{$v['desc']}}
					</div>
				</li>
				@endforeach
				
			</ul>
  		<div class="text-c mb-20" id="moreBlog">
            <a class="btn  radius btn-block " href="javascript:;" onclick="moreBlog('${blogType.id}','${tag.name}');">点击加载更多</a>
            <a class="btn  radius btn-block hidden" href="javascript:;">加载中……</a>
        </div>		
  </div>
  
  <!--right-->
  <div class="col-sm-3 col-md-3 mt-20">

	<!-- 搜索 -->
	<div class="panel panel-primary mb-20">
		<div class="panel-body">
			<form action="{{route('learn')}}" method="get">
				<input type="text" name="keyword" id="" class="btn btn-primary-outline" required value="{{$keyword}}">
				<input type="submit" value="搜索" class="btn btn-primary" style="width:50px;">
			</form>
		</div>
	</div>
	
  	<!--导航-->
  	<div class="panel panel-primary mb-20">
		<div class="panel-body">
			@foreach($types as $k => $v)
			<a href="/learn?keyword={{$v['name']}}">
				<input class="btn btn-primary-outline radius nav-btn" type="button" value="{{$v['name']}}" style="font-size:13px;">
			</a>
			<!-- -outline -->
			@endforeach
		</div>
	</div>
  	
  	<!--热门推荐-->
  	<div class="bg-fff box-shadow radius mb-20">
			<div class="tab-category">
				<a href=""><strong>随便看看</strong></a>
			</div>
			<div class="tab-category-item">
				<ul class="index_recd">
				@foreach($look_articles as $k => $v)
				<li>
					<a href="/item?art={{$v['id']}}">{{$v['title']}}</a>
					<p class="hits"><i class="Hui-iconfont" title="点击量">&#xe622;</i> 276 </p>
				</li>
				@endforeach
				</ul>
			</div>
		</div>
	
<!--标签-->
		<div class="bg-fff box-shadow radius mb-20">
			<div class="tab-category">
				<a href=""><strong>标签云</strong></a>
			</div>
			<div class="tab-category-item">
				<div class="tags"> 
					@foreach($tags as $k => $v)
					<a href="/learn?keyword={{$v['name']}}">{{$v['name']}}</a>
					@endforeach
				</div>
			</div>
		</div>
  </div>
  
</section>

@include('layout.foot');

<script type="text/javascript" src="plugin/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript" src="plugin/layer/3.0/layer.js"></script>
<script type="text/javascript" src="plugin/h-ui/js/H-ui.min.js"></script>
<script type="text/javascript" src="plugin/pifu/pifu.js"></script>
<script type="text/javascript" src="js/common.js"></script>
<script> $(function(){ $(window).on("scroll",backToTopFun); backToTopFun(); }); </script>
<script>
$(function(){
//标签
	$(".tags a").each(function(){
		var x = 9;
		var y = 0;
		var rand = parseInt(Math.random() * (x - y + 1) + y);
		$(this).addClass("tags"+rand)
	});
	
	$("img.lazyload").lazyload({failurelimit : 3});
});

</script> 
</body>
</html>
