<footer class="footer mt-20">
    <div class="container-fluid" id="foot">
        <p>Copyright &copy; 2016-2017 www.wfyvv.com <br>
            <a href="http://www.miitbeian.gov.cn/" target="_blank">皖ICP备17002922号</a><br>
        </p>
    </div>
</footer>