<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Article;
use App\Models\Type;
use App\Models\Talk;
use App\Models\Tag;
use App\Models\Recommend;

class ArticleController extends Controller
{   
    // 文章内容页
    public function item(Request $req)
    {   
        $id = $req->art;
        if(!$id)
        {
            return back();
        }

        $article = Article::where('id',$id)->first();
        if(!$article)
        {
            return back();
        }

        // 上一篇 下一篇
        $page = [];
        $page['left'] = Article::select('id','title')->where('id','<',$article['id'])->orderBy('id','desc')->first();
        $page['right'] = Article::select('id','title')->where('id','>',$article['id'])->orderBy('id','asc')->first();


        // 随便看看
        $look_articles = self::look_articles();

        return view('home.article_detail',['article'=>$article,'page'=>$page,'look_articles'=>$look_articles]);
    }

    // 碎言碎语
    public function talk()
    {
        $talk = Talk::orderBy('created_at','desc')->get();
        return view('home.mood',['talk'=>$talk]);
    }
    
    // 学无止境
    public function learn(Request $req)
    {   
        $keyword = $req->keyword;

        if($keyword)
        {
            $articles = Article::search($keyword)->get();
        }
        else
        {   
            $keyword = "";
            $articles = Article::orderBy('created_at','desc')->get();
        }

        // 类型
        $type = [];
        foreach($articles as $k => $v)
        {
            $type[$k]['name'] = Type::where('id',$v['id'])->first()['name'];
        }

        // 随便看看
        $look_articles = self::look_articles();

        // 标签
        $tags = Tag::take(10)->get();

        $types = Type::get();

        
        return view('home.article',[
            'articles'=>$articles,
            'type'=>$type,
            'types'=>$types,
            'keyword'=>$keyword,
            'look_articles'=>$look_articles,
            'tags' => $tags
            ]);
    }

    // 留言板
    public function message()
    {
        // $message = 
        return view('home.board');
    }

    // 随便看看
    public static function look_articles()
    {
        $article_id = Recommend::where('type',1)->get();
        $articles = [];
        foreach($article_id as $k => $v)
        {
            $articles[] = Article::where('id',$v['art_id'])->first(); 
        }
        return $articles;
    }

}
