<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Article;
use App\Models\Type;
use App\Models\Tag;

class IndexController extends Controller
{
    public function index()
    {   
        // 文章
        $articles = Article::orderBy('created_at','desc')->take(10)->get();
        // 类型
        $type = [];
        foreach($articles as $k => $v)
        {
            $type[$k]['name'] = Type::where('id',$v['type'])->first()['name'];
        }
        // 置顶
        $top = Article::where('is_top',1)->get();
        
        // 随便看看
        $look_articles = ArticleController::look_articles();

        // 标签
        $tags = Tag::take(10)->get();

        // dd($articles,$type);    
        return view('index',['articles'=>$articles,'type'=>$type,'top'=>$top,'look_articles'=>$look_articles,'tags'=>$tags]);
    }
}
