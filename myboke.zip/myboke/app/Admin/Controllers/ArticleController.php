<?php

namespace App\Admin\Controllers;

use App\Models\Article;
use App\Http\Controllers\Controller;
use Encore\Admin\Controllers\HasResourceActions;
use Encore\Admin\Form;
use Encore\Admin\Grid;
use Encore\Admin\Layout\Content;
use Encore\Admin\Show;

use App\Models\Type;

class ArticleController extends Controller
{
    use HasResourceActions;

    /**
     * Index interface.
     *
     * @param Content $content
     * @return Content
     */
    public function index(Content $content)
    {
        return $content
            ->header('Index')
            ->description('description')
            ->body($this->grid());
    }

    /**
     * Show interface.
     *
     * @param mixed $id
     * @param Content $content
     * @return Content
     */
    public function show($id, Content $content)
    {
        return $content
            ->header('Detail')
            ->description('description')
            ->body($this->detail($id));
    }

    /**
     * Edit interface.
     *
     * @param mixed $id
     * @param Content $content
     * @return Content
     */
    public function edit($id, Content $content)
    {
        return $content
            ->header('Edit')
            ->description('description')
            ->body($this->form()->edit($id));
    }

    /**
     * Create interface.
     *
     * @param Content $content
     * @return Content
     */
    public function create(Content $content)
    {
        return $content
            ->header('Create')
            ->description('description')
            ->body($this->form());
    }

    /**
     * Make a grid builder.
     *
     * @return Grid
     */
    protected function grid()
    {
        $grid = new Grid(new Article);

        $grid->id('Id');
        $grid->title('Title'); 
        $grid->img('Img')->display(function($img){
            return "<img src='/uploads/$img' style='width:50px;height:50px;' />";
        });
        $grid->type('Type')->display(function($id){
            return Type::where('id',$id)->first()['name'];
        });
        $grid->tag('Tag'); 
        $grid->look_num('Look num');
        $grid->is_top('状态')->radio([
            0 => '取消置顶',
            1 => '置顶',
        ]);
        $grid->created_at('Created at');

        return $grid;
    }

    /**
     * Make a show builder.
     *
     * @param mixed $id
     * @return Show
     */
    protected function detail($id)
    {
        $show = new Show(Article::findOrFail($id));

        $show->id('Id');
        $show->title('Title');
        $show->type('Type');
        $show->tag('Tag');
        $show->content('Content')->unescape();
        $show->img('Img');
        $show->look_num('Look num');
        $show->created_at('Created at');
        $show->updated_at('Updated at');

        return $show;
    }

    /**
     * Make a form builder.
     *
     * @return Form
     */
    protected function form()
    {
        $form = new Form(new Article);

        $form->text('title', 'Title')->rules('required');
        $form->select('type', 'Type')->options(Type::all()->pluck('name', 'id'))->rules('required');
        $form->text('tag', 'Tag')->rules('required');
        $form->text('desc','前言')->rules('required');
        $form->select('img','Img')->options(Type::all()->pluck('name','img'));
        $form->switch('is_top', '是否置顶')->rules('required');
        $form->editor('content', 'Content')->rules('required');
        $form->hidden('look_num', 'Look num')->default(0);

        return $form;
    }
}
