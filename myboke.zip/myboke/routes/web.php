<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// 博客主页
Route::get('/','IndexController@index')->name('index');

// 列表页
Route::get('/list','ArticleController@list')->name('list');

// 内容页
Route::get('/item','ArticleController@item')->name('item');

// 碎言碎语
Route::get('/talk','ArticleController@talk')->name('talk');

// 学无止境
Route::get('/learn','ArticleController@learn')->name('learn');

// 留言板
Route::get('/message','ArticleController@message')->name('message');

// 关于我
Route::get('/about',function(){
    return view('home.about');
})->name('about');



