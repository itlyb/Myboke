<!DOCTYPE HTML>
<html>
<head>
<title>IT_LYB 博客个人博客 — 一个站在PHP开发之路上的草根程序员个人博客网站</title>
<meta charset="utf-8">
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" />
<meta http-equiv="Cache-Control" content="no-siteapp" />
<meta name="keywords" content="个人博客,IT_LYB 博客个人博客,个人博客系统,IT_LYB 博客博客,IT_LYB 博客">
<meta name="description" content="IT_LYB 博客博客系统，一个站在PHP开发之路上的草根程序员个人博客网站。">
<LINK rel="Bookmark" href="favicon.ico" >
<LINK rel="Shortcut Icon" href="favicon.ico" />
<!--[if lt IE 9]>
<script type="text/javascript" src="/staticRes/js/html5shiv.js"></script>
<script type="text/javascript" src="/staticRes/js/respond.min.js"></script>
<![endif]-->
<link rel="stylesheet" type="text/css" href="plugin/h-ui/css/H-ui.min.css" />
<link rel="stylesheet" type="text/css" href="plugin/Hui-iconfont/1.0.8/iconfont.min.css" />
<link rel="stylesheet" type="text/css" href="css/common.css" />
<link rel="stylesheet" type="text/css" href="plugin/pifu/pifu.css" />
<link rel="stylesheet" type="text/css" href="plugin/wangEditor/css/wangEditor.min.css">
<!--[if lt IE 9]>
<link href="/staticRes/lib/h-ui/css/H-ui.ie.css" rel="stylesheet" type="text/css" />
<![endif]-->
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } function showSide(){$('.navbar-nav').toggle();}</script>
</head>
<body>

<?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!--导航条-->
<nav class="breadcrumb">
  <div class="container"> 
	  <i class="Hui-iconfont">&#xe67f;</i> <a href="/" class="c-primary">首页</a>
	   <span class="c-gray en">&gt;</span>  <span class="c-gray">文章</span>
	    <span class="c-gray en">&gt;</span>  <span class="c-gray"><?php echo e($article['title'], false); ?></span></div>
</nav>

<section class="container pt-20">
	
	<div class="row w_main_row">
				
				
				<div class="col-lg-9 col-md-9 w_main_left">


					<!-- 文章内容 start -->
					<div class="panel panel-default  mb-20">
						<div class="panel-body pt-10 pb-10">
							<h2 class="c_titile"><?php echo e($article['title'], false); ?></h2>
							<p class="box_c">
								<span class="d_time">发布时间：<?php echo e($article['created_at'], false); ?></span>
								<span>编辑：<a href="javascript:;">IT_LYB</a></span>
								<span>阅读（88646）</span>
							</p>
							<ul class="infos">
								<?php echo $article['content']; ?>

							</ul>
															
							<div class="keybq">
								<p><span>关键字</span>：
									<a class="javascript:;"><?php echo e($article['tag'], false); ?></a>
								</p>    
						    </div>
							
							<div class="nextinfo">
								<?php if(isset($page['left'])): ?>
								<p class="last">上一篇：<a href="/item?art=<?php echo e($page['left']['id'], false); ?>"><?php echo e($page['left']['title'], false); ?></a></p>
								<?php endif; ?>
								<?php if(isset($page['right'])): ?>
								<p class="next">下一篇：<a href="/item?art=<?php echo e($page['right']['id'], false); ?>"><?php echo e($page['right']['title'], false); ?></a></p>
								<?php endif; ?>
						    </div>

						</div>
					</div>
					<!-- 文章内容 end -->


					<!-- 评论 start -->
					<div class="panel panel-default  mb-20">
						<!-- <div class="tab-category">
            				<a href=""><strong>评论区</strong></a>
            			</div> -->
						<div class="panel-body">
							<div class="panel-body" style="margin: 0 3%;">
							<!-- <div class="mb-20">
								<ul class="commentList">
									<li class="item cl"> <a href="#"><i class="avatar size-L radius"><img alt="" src="http://qzapp.qlogo.cn/qzapp/101388738/1CF8425D24660DB8C3EBB76C03D95F35/100"></i></a>
										<div class="comment-main">
											<header class="comment-header">
												<div class="comment-meta"><a class="comment-author" href="#">老王</a>
													<time title="2014年8月31日 下午3:20" datetime="2014-08-31T03:54:20" class="f-r">2014-8-31 15:20</time>
												</div>
											</header>
											<div class="comment-body">
												<p> 是的</p>
											</div>
										</div>
									</li>
									<li class="item cl"> <a href="#"><i class="avatar size-L radius"><img alt="" src="http://qzapp.qlogo.cn/qzapp/101388738/696C8A17B3383B88804BA92ECBAA5D81/100"></i></a>
										<div class="comment-main">
											<header class="comment-header">
												<div class="comment-meta"><a class="comment-author" href="#">老王</a>
													<time title="2014年8月31日 下午3:20" datetime="2014-08-31T03:54:20" class="f-r">2014-8-31 15:20</time>
												</div>
											</header>
											<div class="comment-body">
												<p> +1</p>
											</div>
										</div>
									</li>

								</ul>
			
							</div> -->
							<!-- <div class="line"></div> -->
							<!--用于评论-->
							<!-- <div class="mt-20" id="ct">
								<div id="err" class="Huialert Huialert-danger hidden radius">成功状态提示</div>
								<textarea id="textarea1" name="comment" style="height:200px;" placeholder="看完不留一发？"> </textarea>
								<div class="text-r mt-10">
									<button onclick="getPlainTxt()" class="btn btn-primary radius" > 发表评论</button>
								</div>
							</div> -->
							<!--用于回复-->
							<!-- <div class="comment hidden mt-20">
								<div id="err2" class="Huialert Huialert-danger hidden radius">成功状态提示</div>
									<textarea class="textarea" style="height:100px;" > </textarea>
									<button onclick="hf(this);" type="button" class="btn btn-primary radius mt-10">回复</button>
									<a class="cancelReply f-r mt-10">取消回复</a>
							</div> -->

                			</div>
						</div>
					</div>
					<!-- 评论 end -->

				</div>


				<!-- 右侧 start -->
				<div class="col-lg-3 col-md-3">
					<!--热门推荐-->
					<div class="bg-fff box-shadow radius mb-20">
							<div class="tab-category">
								<a href=""><strong>随便看看</strong></a>
							</div>
							<div class="tab-category-item">
								<ul class="index_recd">
									<?php $__currentLoopData = $look_articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li>
										<a href="/item?art=<?php echo e($v['id'], false); ?>"><?php echo e($v['title'], false); ?></a>
										<p class="hits"><i class="Hui-iconfont" title="点击量">&#xe622;</i> 276 </p>
									</li>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</ul>
							</div>
					</div>
					
					
				</div>
			</div>
	
</section>


<?php echo $__env->make('layout.foot', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>;


<script type="text/javascript" src="plugin/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript" src="plugin/layer/3.0/layer.js"></script>
<script type="text/javascript" src="plugin/h-ui/js/H-ui.min.js"></script>
<script type="text/javascript" src="plugin/pifu/pifu.js"></script>
<script type="text/javascript" src="js/common.js"></script>
<script> $(function(){ $(window).on("scroll",backToTopFun); backToTopFun(); }); </script>
<script type="text/javascript" src="plugin/wangEditor/js/wangEditor.min.js"></script>
<script type="text/javascript">
    $(function () {
    		$("img.lazyload").lazyload({failurelimit : 3});
    	
        wangEditor.config.printLog = false;
        var editor1 = new wangEditor('textarea1');
        editor1.config.menus = ['insertcode', 'quote', 'bold', '|', 'img', 'emotion', '|', 'undo', 'fullscreen'];
        editor1.config.emotions = { 'default': { title: '老王表情', data: 'plugin/wangEditor/emotions1.data'}, 'default2': { title: '老王心情', data: 'plugin/wangEditor/emotions3.data'}, 'default3': { title: '顶一顶', data: 'plugin/wangEditor/emotions2.data'}};
        editor1.create();

        //show reply
        $(".hf").click(function () {
            pId = $(this).attr("name");
            $(this).parents(".commentList").find(".cancelReply").trigger("click");
            $(this).parent(".comment-body").append($(".comment").clone(true));
            $(this).parent(".comment-body").find(".comment").removeClass("hidden");
            $(this).hide();
        });
        //cancel reply
        $(".cancelReply").on('click',function () {
            $(this).parents(".comment-body").find(".hf").show();
            $(this).parents(".comment-body").find(".comment").remove();
        });
    });

</script>
</body>
</html>
