<!DOCTYPE HTML>
<html>
<head>
<title>IT_LYB 博客个人博客 — 一个站在PHP开发之路上的草根程序员个人博客网站</title>
<meta charset="utf-8">
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" />
<meta http-equiv="Cache-Control" content="no-siteapp" />
<meta name="keywords" content="个人博客,IT_LYB 博客个人博客,个人博客系统,IT_LYB 博客博客,IT_LYB 博客">
<meta name="description" content="IT_LYB 博客博客系统，一个站在PHP开发之路上的草根程序员个人博客网站。">
<LINK rel="Bookmark" href="favicon.ico" >
<LINK rel="Shortcut Icon" href="favicon.ico" />
<!--[if lt IE 9]>
<script type="text/javascript" src="/staticRes/js/html5shiv.js"></script>
<script type="text/javascript" src="/staticRes/js/respond.min.js"></script>
<![endif]-->
<link rel="stylesheet" type="text/css" href="plugin/h-ui/css/H-ui.min.css" />
<link rel="stylesheet" type="text/css" href="plugin/Hui-iconfont/1.0.8/iconfont.min.css" />
<link rel="stylesheet" type="text/css" href="css/common.css" />
<link rel="stylesheet" type="text/css" href="plugin/pifu/pifu.css" />
<!--[if lt IE 9]>
<link href="/staticRes/lib/h-ui/css/H-ui.ie.css" rel="stylesheet" type="text/css" />
<![endif]-->
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } function showSide(){$('.navbar-nav').toggle();}</script>
</head>
<body>

<?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!--导航条-->
<nav class="breadcrumb">
    <div class="container">
        <i class="Hui-iconfont">&#xe67f;</i><a href="/" class="c-primary">首页</a>
        <span class="c-gray en">&gt;</span> <a href="/article" class="c-primary">学无止尽</a>
        <!-- <span class="c-gray en">&gt;</span> <span class="c-gray"><i class="Hui-iconfont">&#xe64b;</i> nginx</span> -->
    </div>
</nav>

<section class="container">
  <!--left-->
  <div class="col-sm-9 col-md-9 mt-20">
  	
  		
  	<!--article list-->
			<ul class="index_arc">

				<?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li class="index_arc_item">
					<a href="/item?art=<?php echo e($v['id'], false); ?>" class="pic">
						<img class="lazyload" data-original="uploads/<?php echo e($v['img'], false); ?>" alt="应该选" />
					</a>
					<h4 class="title"><a href="/item?art=<?php echo e($v['id'], false); ?>"><?php echo e($v['title'], false); ?></a></h4>
					<div class="date_hits">
						<span>IT_LYB</span>
						<span><?php echo e($v['created_at'], false); ?></span>
						<span><a href="/article-lists/10.html"><?php echo e($type[$k]['name'], false); ?></a></span>
						<p class="hits"><i class="Hui-iconfont" title="点击量">&#xe6c1;</i> 276° </p>
						<p class="commonts"><i class="Hui-iconfont" title="点击量">&#xe622;</i> <span class="cy_cmt_count">20</span></p>
					</div>
					<div class="desc">
						<?php echo e($v['desc'], false); ?>

					</div>
				</li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				
			</ul>
  		<div class="text-c mb-20" id="moreBlog">
            <a class="btn  radius btn-block " href="javascript:;" onclick="moreBlog('${blogType.id}','${tag.name}');">点击加载更多</a>
            <a class="btn  radius btn-block hidden" href="javascript:;">加载中……</a>
        </div>		
  </div>
  
  <!--right-->
  <div class="col-sm-3 col-md-3 mt-20">

	<!-- 搜索 -->
	<div class="panel panel-primary mb-20">
		<div class="panel-body">
			<form action="<?php echo e(route('learn'), false); ?>" method="get">
				<input type="text" name="keyword" id="" class="btn btn-primary-outline" required value="<?php echo e($keyword, false); ?>">
				<input type="submit" value="搜索" class="btn btn-primary" style="width:50px;">
			</form>
		</div>
	</div>
	
  	<!--导航-->
  	<div class="panel panel-primary mb-20">
		<div class="panel-body">
			<?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<a href="/learn?keyword=<?php echo e($v['name'], false); ?>">
				<input class="btn btn-primary-outline radius nav-btn" type="button" value="<?php echo e($v['name'], false); ?>" style="font-size:13px;">
			</a>
			<!-- -outline -->
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
  	
  	<!--热门推荐-->
  	<div class="bg-fff box-shadow radius mb-20">
			<div class="tab-category">
				<a href=""><strong>随便看看</strong></a>
			</div>
			<div class="tab-category-item">
				<ul class="index_recd">
				<?php $__currentLoopData = $look_articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li>
					<a href="/item?art=<?php echo e($v['id'], false); ?>"><?php echo e($v['title'], false); ?></a>
					<p class="hits"><i class="Hui-iconfont" title="点击量">&#xe622;</i> 276 </p>
				</li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
		</div>
	
<!--标签-->
		<div class="bg-fff box-shadow radius mb-20">
			<div class="tab-category">
				<a href=""><strong>标签云</strong></a>
			</div>
			<div class="tab-category-item">
				<div class="tags"> 
					<?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<a href="/learn?keyword=<?php echo e($v['name'], false); ?>"><?php echo e($v['name'], false); ?></a>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
		</div>
  </div>
  
</section>

<?php echo $__env->make('layout.foot', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>;

<script type="text/javascript" src="plugin/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript" src="plugin/layer/3.0/layer.js"></script>
<script type="text/javascript" src="plugin/h-ui/js/H-ui.min.js"></script>
<script type="text/javascript" src="plugin/pifu/pifu.js"></script>
<script type="text/javascript" src="js/common.js"></script>
<script> $(function(){ $(window).on("scroll",backToTopFun); backToTopFun(); }); </script>
<script>
$(function(){
//标签
	$(".tags a").each(function(){
		var x = 9;
		var y = 0;
		var rand = parseInt(Math.random() * (x - y + 1) + y);
		$(this).addClass("tags"+rand)
	});
	
	$("img.lazyload").lazyload({failurelimit : 3});
});

</script> 
</body>
</html>
